﻿using System.IO.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FileTransactedTest
{
    
    
    /// <summary>
    ///This is a test class for TransactionTest and is intended
    ///to contain all TransactionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class TransactionTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for CreateTransaction
        ///</summary>
        [TestMethod()]
        public void CreateTransactionTest()
        {
            Transaction actual;
            actual = new Transaction();

        }

        /// <summary>
        ///A test for CommitTransaction
        ///</summary>
        [TestMethod()]
        public void CommitTransactionTest()
        {
            Transaction transaction = new Transaction();
            
            int actual;
            actual = transaction.Commit();
        }

        /// <summary>
        ///A test for RollbackTransaction
        ///</summary>
        [TestMethod()]
        public void RollbackTransactionTest()
        {
            Transaction transaction = new Transaction();

            int actual;
            actual = transaction.Rollback();
        }

        /// <summary>
        ///A test for Close
        ///</summary>
        [TestMethod()]
        public void CloseTest()
        {
            using (Transaction t = new Transaction())
            {
                int i = 0;
            }


        }

  
    }
}
