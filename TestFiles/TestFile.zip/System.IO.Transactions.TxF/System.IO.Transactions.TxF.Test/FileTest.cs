﻿using System.IO.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Transactions;

namespace FileTransactedTest
{
    
    
    /// <summary>
    ///This is a test class for FileTest and is intended
    ///to contain all FileTest Unit Tests
    ///</summary>
    [TestClass()]
    public class FileTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Copy
        ///</summary>
        [TestMethod()]
        public void CopyTest()
        {
            string sourceFileName = @"c:\tmp\ktm\FileTransactedTest\FileTest\Test.source";
            string destFileName = @"c:\tmp\ktm\FileTransactedTest\FileTest\Test.dest";
            string destFileName2 = @"c:\tmp\ktm\FileTransactedTest\FileTest\Test2.dest";
            bool overwrite = true;

            using (System.IO.Transactions.Transaction transaction = new System.IO.Transactions.Transaction())
            {
                File.Copy(sourceFileName, destFileName, overwrite, transaction);
                transaction.Commit();
            }
        }

        /// <summary>
        ///A test for Copy
        ///</summary>
        [TestMethod()]
        public void CopyTest2()
        {
            string sourceFileName = @"c:\tmp\ktm\FileTransactedTest\FileTest\Test.source";
            string destFileName = @"c:\tmp\ktm\FileTransactedTest\FileTest\Test.dest";
            string destFileName2 = @"c:\tmp\ktm\FileTransactedTest\FileTest\Test2.dest";
            bool overwrite = true;

            using (System.Transactions.TransactionScope ts = new System.Transactions.TransactionScope())
            {
                File.Copy(sourceFileName, destFileName, overwrite, ts);
                ts.Complete();
            }
        }


        /// <summary>
        ///A test for CreateFileTransacted
        ///</summary>
        [TestMethod()]
        public void CreateFileTransactedTest()
        {
            using (System.IO.Transactions.Transaction transaction = new System.IO.Transactions.Transaction())
            {
                IntPtr actual = File.CreateFile("c:\\tmp\\out.txt",File.CreationDisposition.CreatesNewfileIfNotExist  , transaction);

                

                transaction.Commit();
            }
        }

        /// <summary>
        ///A test for WriteFile
        ///</summary>
        [TestMethod()]
        public void WriteFileTest()
        {
            byte[] data = System.IO.File.ReadAllBytes("c:\\tmp\\test.rar");

            using (System.IO.Transactions.Transaction transaction = new System.IO.Transactions.Transaction())
            {


                IntPtr actual = File.CreateFile("c:\\tmp\\out.bin", File.CreationDisposition.CreatesNewfileAlways, transaction);

                

                int result = File.WriteFile(actual, data);
                
                transaction.Commit();
            }            
        }


        /// <summary>
        ///A test for ReadFile
        ///</summary>
        [TestMethod()]
        public void ReadFileTest()
        {
            string file = "c:\\tmp\\Test.rar";
            
            byte[] actual;
            actual = File.ReadFile(file);

            using (System.IO.Transactions.Transaction transaction = new System.IO.Transactions.Transaction())
            {
                IntPtr f = File.CreateFile("c:\\tmp\\out.bin", File.CreationDisposition.CreatesNewfileAlways, transaction);
                int result = File.WriteFile(f, actual);
                transaction.Commit();
            }   

        }

        /// <summary>
        ///A test for DeleteFile
        ///</summary>
        [TestMethod()]
        public void DeleteFileTest()
        {
            string file = "c:\\tmp\\Test.rar";

            byte[] actual;
            actual = File.ReadFile(file);

            using (System.IO.Transactions.Transaction transaction = new System.IO.Transactions.Transaction())
            {
                IntPtr f = File.CreateFile("c:\\tmp\\out.bin", File.CreationDisposition.CreatesNewfileAlways, transaction);
                int result = File.WriteFile(f, actual);
                transaction.Commit();
            }

            using (System.IO.Transactions.Transaction transaction = new System.IO.Transactions.Transaction())
            {
                File.DeleteFile("c:\\tmp\\out.bin", transaction);
                transaction.Commit();
            }   
        }

    }
}
