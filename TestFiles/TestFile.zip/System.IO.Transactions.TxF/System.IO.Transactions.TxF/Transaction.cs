﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.IO.Transactions.WindowsApi;

namespace System.IO.Transactions
{
    public class Transaction:IDisposable
    {
        public Transaction()
        {
            this.TransactionHandle = IntPtr.Zero;
            Create();
        }
        internal Transaction(System.Transactions.TransactionScope transactionScope)
        {
            this.TransactionHandle = IntPtr.Zero;
            this.TransactionHandle = _GetPtrFromDtc();
        }

        public IntPtr TransactionHandle { get; private set; }

        private IntPtr _GetPtrFromDtc()
        {
            apiwindows.IKernelTransaction dtcT = (apiwindows.IKernelTransaction)System.Transactions.TransactionInterop.GetDtcTransaction(System.Transactions.Transaction.Current);
            IntPtr result = IntPtr.Zero;
            dtcT.GetHandle(out result);
            return result;
        }

        private IntPtr Create()
        {
            apiwindows.LPSECURITY_ATTRIBUTES lpTransactionAttributes = new apiwindows.LPSECURITY_ATTRIBUTES();
            apiwindows.LPGUID UOW = new apiwindows.LPGUID();
            UOW.Value = IntPtr.Zero;
            int CreateOptions = 0;
            int IsolationLevel = 0;
            int IsolationFlags = 0;
            int Timeout = 0;
            StringBuilder Description = new StringBuilder("ND");
            IntPtr transactionHandle = apiwindows.CreateTransaction(lpTransactionAttributes, UOW, CreateOptions, IsolationLevel, IsolationFlags, Timeout, Description);

            if (transactionHandle == IntPtr.Zero)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            this.TransactionHandle = transactionHandle;
            return transactionHandle;
        }

        public int Commit()
        { 
            int result = apiwindows.CommitTransaction(this.TransactionHandle);

            if (result == 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            return result;
        }

        public int Rollback()
        {
            int result = apiwindows.RollbackTransaction(this.TransactionHandle);

            if (result == 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            return result;
        }

        public int Close()
        {
            int result = apiwindows.CloseHandle(this.TransactionHandle);

            if (result == 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            return result;
        }

        public void Dispose()
        {
            this.Close();
        }
    }
}
