﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace System.IO.Transactions.WindowsApi
{
    class HandlePoint : IDisposable
    {
        private GCHandle _h;
        public HandlePoint(object o)
        {
            _h = GCHandle.Alloc(o, GCHandleType.Pinned);
            try
            {
                IntPtr oIntPtr = GCHandle.ToIntPtr(_h);
                this.ObjPoiter = oIntPtr;
            }
            catch (Exception)
            {
                this.Dispose();
                throw;
            }
        }

        public IntPtr ObjPoiter
        { get; private set; }

        public void Dispose()
        {
            if(_h!=null )
                _h.Free();
        }
    }

    static class apiwindows
    {
        static apiwindows()
        { }

        public static readonly int INVALID_HANDLE_VALUE = unchecked((int)0xFFFFFFFF);
        public static readonly int INVALID_FILE_SIZE = unchecked((int)0xFFFFFFFF);
        public static readonly int HFILE_ERROR = unchecked((int)0xFFFFFFFF);
        
        
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Explicit)]
        public struct LARGE_INTEGER
        {
            [System.Runtime.InteropServices.FieldOffset(0)]
            public sType s;
            [System.Runtime.InteropServices.FieldOffset(0)]
            public uType u;
            [System.Runtime.InteropServices.FieldOffset(0)]
            public long QuadPart;

            [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
            public struct sType
            {
                public int LowPart;
                public int HighPart;
            }

            [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
            public struct uType
            {
                public int LowPart;
                public int HighPart;
            }
        }

        [System.Runtime.InteropServices.UnmanagedFunctionPointer(System.Runtime.InteropServices.CallingConvention.StdCall)]
        public delegate int LPPROGRESS_ROUTINE(
            LARGE_INTEGER TotalFileSize,
            LARGE_INTEGER TotalBytesTransferred,
            LARGE_INTEGER StreamSize,
            LARGE_INTEGER StreamBytesTransferred,
            int dwStreamNumber,
            int dwCallbackReason,
            System.IntPtr hSourceFile,
            System.IntPtr hDestinationFile,
            System.IntPtr lpData);

        #region CopyFile
        public enum COPY_FLAGS
        {
            COPY_FILE_COPY_ND = 0,
            COPY_FILE_COPY_SYMLINK = 0x800,
            COPY_FILE_FAIL_IF_EXISTS = 0x1,
            COPY_FILE_OPEN_SOURCE_FOR_WRITE = 0x4,
            COPY_FILE_RESTARTABLE = 0x2
        }
        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int CopyFileTransactedW(
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpExistingFileName,
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpNewFileName,
            LPPROGRESS_ROUTINE lpProgressRoutine,
            System.IntPtr lpData,
            ref int pbCancel,
            COPY_FLAGS dwCopyFlags,
            System.IntPtr hTransaction);
        #endregion

        #region CreateFileTransacted
        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static System.IntPtr CreateFileTransactedW(
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpFileName,
            DesiredAccess dwDesiredAccess,
            ShareMode dwShareMode,
            LPSECURITY_ATTRIBUTES lpSecurityAttributes,
            CreationDisposition dwCreationDisposition,
            FlagsAndAttributes dwFlagsAndAttributes,
            System.IntPtr hTemplateFile,
            System.IntPtr hTransaction,
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] System.Text.StringBuilder pusMiniVersion,
            System.IntPtr lpExtendedParameter);

        public enum DesiredAccess
        { 
            GENERIC_READ = unchecked((int)0x80000000),
            GENERIC_WRITE = 0x40000000   
        }

        public enum ShareMode
        {
            FILE_SHARE_ND = 0,
            FILE_SHARE_DELETE = 0x4,
            FILE_SHARE_READ = 0x1,
            FILE_SHARE_WRITE = 0x2
        }

        public enum CreationDisposition
        { 
            CREATE_ALWAYS = 0x2,
            CREATE_NEW = 0x1,
            OPEN_ALWAYS = 0x4,
            OPEN_EXISTING = 0x3,
            TRUNCATE_EXISTING = 0x5
        }

        public enum FlagsAndAttributes
        { 
            FILE_ATTRIBUTE_ARCHIVE = 0x20,
            FILE_ATTRIBUTE_ENCRYPTED = 0x4000,
            FILE_ATTRIBUTE_HIDDEN = 0x2,
            FILE_ATTRIBUTE_NORMAL = 0x80,
            FILE_ATTRIBUTE_OFFLINE = 0x1000,
            FILE_ATTRIBUTE_READONLY = 0x1,
            FILE_ATTRIBUTE_SYSTEM = 0x4,
            FILE_ATTRIBUTE_TEMPORARY = 0x100,
            FILE_FLAG_BACKUP_SEMANTICS = 0x2000000,
            FILE_FLAG_DELETE_ON_CLOSE = 0x4000000,
            FILE_FLAG_NO_BUFFERING = 0x20000000,
            FILE_FLAG_OPEN_NO_RECALL = 0x100000,
            FILE_FLAG_OPEN_REPARSE_POINT = 0x200000,
            FILE_FLAG_OVERLAPPED = 0x40000000,
            FILE_FLAG_POSIX_SEMANTICS = 0x1000000,
            FILE_FLAG_RANDOM_ACCESS = 0x10000000,
            FILE_FLAG_SEQUENTIAL_SCAN = 0x8000000,
            FILE_FLAG_WRITE_THROUGH = unchecked((int)0x80000000)
        }

        public enum MiniVersion
        {
            TXFS_MINIVERSION_COMMITTED_VIEW = 0x0000,
            TXFS_MINIVERSION_DIRTY_VIEW = 0xFFFF,
            TXFS_MINIVERSION_DEFAULT_VIEW = 0xFFFE
        }
        #endregion

        #region WriteFile & ReadFile

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        public struct LPOVERLAPPED
        {
            public System.IntPtr Value;
        }
        
        [System.Runtime.InteropServices.UnmanagedFunctionPointer(System.Runtime.InteropServices.CallingConvention.StdCall)]
        public delegate void LPOVERLAPPED_COMPLETION_ROUTINE(int dwErrorCode,int dwNumberOfBytesTransfered,LPOVERLAPPED lpOverlapped);
        
        //[System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        //public extern static int WriteFileEx(System.IntPtr hFile, byte[] lpBuffer, int nNumberOfBytesToWrite, LPOVERLAPPED lpOverlapped, LPOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine);

        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int WriteFile(System.IntPtr hFile,byte[] lpBuffer,int nNumberOfBytesToWrite,ref int lpNumberOfBytesWritten,LPOVERLAPPED lpOverlapped);
        
        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int ReadFile(System.IntPtr hFile, byte[] lpBuffer, int nNumberOfBytesToRead, ref int lpNumberOfBytesRead, LPOVERLAPPED lpOverlapped);
        
        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int GetFileSize(System.IntPtr hFile,ref int lpFileSizeHigh);

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential,CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
        public struct OFSTRUCT
        {
            public byte cBytes;
            public byte fFixedDisk;
            public short nErrCode;
            public short Reserved1;
            public short Reserved2;
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst = 128)]
            public string szPathName;
        }

        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static IntPtr OpenFile([System.Runtime.InteropServices.In][System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPStr)] System.Text.StringBuilder lpFileName,ref OFSTRUCT lpReOpenBuff,Style uStyle);

        #endregion

        #region Delete & Move File

        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int DeleteFileTransactedW([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpFileName,System.IntPtr hTransaction);

        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int MoveFileTransactedW(
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpExistingFileName,
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpNewFileName,
            LPPROGRESS_ROUTINE lpProgressRoutine,
            System.IntPtr lpData,
            int dwFlags,
            System.IntPtr hTransaction);
        

        #endregion 

        public enum Style
        {
            OF_CANCEL = 0x800,
            OF_CREATE = 0x1000,
            OF_DELETE = 0x200,
            OF_EXIST = 0x4000,
            OF_PARSE = 0x100,
            OF_PROMPT = 0x2000,
            OF_READ = 0x0,
            OF_READWRITE = 0x2,
            OF_REOPEN = 0x8000,
            OF_SHARE_COMPAT = 0x0,
            OF_SHARE_DENY_NONE = 0x40,
            OF_SHARE_DENY_READ = 0x30,
            OF_SHARE_DENY_WRITE = 0x20,
            OF_SHARE_EXCLUSIVE = 0x10,
            OF_VERIFY = 0x400,
            OF_WRITE = 0x1
        }

        #region Folders
        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int CreateDirectoryTransactedW(
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpTemplateDirectory,
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpNewDirectory,
            LPSECURITY_ATTRIBUTES lpSecurityAttributes,
            System.IntPtr hTransaction);
        
        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int RemoveDirectoryTransactedW(
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string lpPathName,
            System.IntPtr hTransaction);
        
        #endregion

        #region Transaction
        [Guid("79427A2B-F895-40e0-BE79-B57DC82ED231")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IKernelTransaction
        {
            int GetHandle(out IntPtr pHandle);
        }

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        public struct LPSECURITY_ATTRIBUTES
        {
            public System.IntPtr Value;
        }
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        public struct LPGUID
        {
            public System.IntPtr Value;
        }
        [System.Runtime.InteropServices.DllImport("ktmw32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static System.IntPtr CreateTransaction(
            LPSECURITY_ATTRIBUTES lpTransactionAttributes,
            LPGUID UOW,
            int CreateOptions,
            int IsolationLevel,
            int IsolationFlags,
            int Timeout,
            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] System.Text.StringBuilder Description);       

        [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int CloseHandle(System.IntPtr hObject);
        
        [System.Runtime.InteropServices.DllImport("ktmw32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int CommitTransaction(System.IntPtr TransactionHandle);
        
        [System.Runtime.InteropServices.DllImport("ktmw32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        public extern static int RollbackTransaction(System.IntPtr TransactionHandle);
       
        //[System.Runtime.InteropServices.DllImport("ktmw32.dll",SetLastError = true,CallingConvention = System.Runtime.InteropServices.CallingConvention.StdCall)]
        //public extern static System.IntPtr OpenTransaction(int dwDesiredAccess,LPGUID TransactionId);

        //public enum TransactionAccessMasks:int
        //{
        //    TRANSACTION_QUERY_INFORMATION = 0x1,
        //    TRANSACTION_SET_INFORMATION = 0x2,
        //    TRANSACTION_ENLIST = 0x4,
        //    TRANSACTION_COMMIT = 0x8,
        //    TRANSACTION_ROLLBACK = 0x10,
        //    TRANSACTION_PROPAGATE = 0x20,
        //    TRANSACTION_GENERIC_READ = 0x120001,
        //    TRANSACTION_GENERIC_WRITE = 0x12003E,
        //    TRANSACTION_GENERIC_EXECUTE = 0x120018,
        //    TRANSACTION_ALL_ACCESS = 0x1F003F,
        //    TRANSACTION_RESOURCE_MANAGER_RIGHTS = 0x120037
        //}
        

        #endregion

    }
}

