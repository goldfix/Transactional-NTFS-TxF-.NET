﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace System.IO.Transactions
{
    public class FileTransactedException:Exception
    {
        public FileTransactedException(string message): base(message)
        {            
        }
        public FileTransactedException(string message, Exception innerException): base(message, innerException)
        {
        }        
    }
}
