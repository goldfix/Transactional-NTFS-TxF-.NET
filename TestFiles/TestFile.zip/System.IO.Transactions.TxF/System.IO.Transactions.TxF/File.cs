﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.IO.Transactions.WindowsApi;

namespace System.IO.Transactions
{
    public class File
    {
        public File()
        { }


        public static void Copy(string sourceFileName, string destFileName, bool overwrite, System.Transactions.TransactionScope transactionScope)
        {
            
            Transaction t = new Transaction(transactionScope);
            Copy(sourceFileName, destFileName, overwrite, t);
        }
        public static void Copy(string sourceFileName, string destFileName, bool overwrite, Transaction transaction)
        {
            int pbCancel = 0;
            apiwindows.COPY_FLAGS dwCopyFlags = apiwindows.COPY_FLAGS.COPY_FILE_COPY_ND;
            if (!overwrite)
            {
                dwCopyFlags = apiwindows.COPY_FLAGS.COPY_FILE_FAIL_IF_EXISTS;
            }
            int err = apiwindows.CopyFileTransactedW(sourceFileName, destFileName, null, IntPtr.Zero, ref pbCancel, dwCopyFlags, transaction.TransactionHandle);

            if (err == 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
        }

        public enum CreationDisposition
        {
            CreatesNewfileAlways = apiwindows.CreationDisposition.CREATE_ALWAYS,
            CreatesNewfileIfNotExist = apiwindows.CreationDisposition.CREATE_NEW,
            OpensFileOrCreate = apiwindows.CreationDisposition.OPEN_ALWAYS,
            OpensFile = apiwindows.CreationDisposition.OPEN_EXISTING,
            OpensFileAndTruncate = apiwindows.CreationDisposition.TRUNCATE_EXISTING
        }

        public static int CreateAndWriteFile(string fileName, CreationDisposition creationDisposition, byte[] data, System.Transactions.TransactionScope transactionScope)
        {
            Transaction t = new Transaction(transactionScope);
            return CreateAndWriteFile(fileName, creationDisposition, data, t);
        }
        public static int CreateAndWriteFile(string fileName, CreationDisposition creationDisposition,byte[] data, Transaction transaction)
        {
            IntPtr p = CreateFile(fileName, creationDisposition, transaction);
            return WriteFile(p, data);
        }

        public static IntPtr CreateFile(string fileName, CreationDisposition creationDisposition, System.Transactions.TransactionScope transactionScope)
        {
            Transaction t = new Transaction(transactionScope);
            return CreateFile(fileName, creationDisposition, t);
        }
        public static IntPtr CreateFile(string fileName, CreationDisposition creationDisposition, Transaction transaction)
        {
            IntPtr err = apiwindows.CreateFileTransactedW(fileName,
                        apiwindows.DesiredAccess.GENERIC_READ | apiwindows.DesiredAccess.GENERIC_WRITE,
                        apiwindows.ShareMode.FILE_SHARE_ND,
                        new apiwindows.LPSECURITY_ATTRIBUTES(),
                        (apiwindows.CreationDisposition)creationDisposition,
                        apiwindows.FlagsAndAttributes.FILE_ATTRIBUTE_NORMAL | apiwindows.FlagsAndAttributes.FILE_ATTRIBUTE_ARCHIVE,
                        IntPtr.Zero,
                        transaction.TransactionHandle,
                        null,
                        IntPtr.Zero
                        );

            if (err.ToInt32() == apiwindows.INVALID_HANDLE_VALUE)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
            return err;
        }

        public static int WriteFile(IntPtr file, byte[] data)
        {
            try
            {
                int i = 0;
                int err = apiwindows.WriteFile(file, data, data.Length, ref i, new apiwindows.LPOVERLAPPED());
                if (err == 0)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }
                return err;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                apiwindows.CloseHandle(file);
            }            
        }

        public static byte[] ReadFile(string file)
        {
            IntPtr f = _OpenFile(file);
            return _ReadFile(f);
        }


        public static int Delete(string file, System.Transactions.TransactionScope transactionScope)
        {
            Transaction t = new Transaction(transactionScope);
            return DeleteFile(file, t);
        }
        public static int DeleteFile(string file, Transaction transaction )
        {
            try
            {
                int err = apiwindows.DeleteFileTransactedW(file, transaction.TransactionHandle);
                if (err == 0)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }
                return err;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                //--
            }
        }

        private static byte[] _ReadFile(IntPtr file)
        {
            try
            {
                int i = 0;
                int sizeFile = _SizeFile(file);
                byte[] result = new byte[sizeFile];
                int err = apiwindows.ReadFile(file, result,  result.Length, ref  i, new apiwindows.LPOVERLAPPED());
                if (err == 0)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }
                return result;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                apiwindows.CloseHandle(file);
            }            
        }

        private static IntPtr _OpenFile(string file)
        {
            apiwindows.OFSTRUCT of = new apiwindows.OFSTRUCT();
            IntPtr result = apiwindows.OpenFile(new StringBuilder(file), ref of, apiwindows.Style.OF_READ);
            if (result.ToInt32() == (int)apiwindows.HFILE_ERROR)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
            return result;
        }

        private static int _SizeFile(IntPtr file)
        {
            int i = 0;
            int result = apiwindows.GetFileSize(file, ref i);
            if (result == apiwindows.INVALID_FILE_SIZE)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
            return result;
        }
    }
}
