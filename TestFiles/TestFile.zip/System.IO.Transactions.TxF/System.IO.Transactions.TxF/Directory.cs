﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.IO.Transactions.WindowsApi;

namespace System.IO.Transactions
{
    public class Directory
    {
        public Directory()
        {

        }

        public static void CreateDirectory(string path, System.Transactions.TransactionScope transactionScope)
        {
            Transaction t = new Transaction(transactionScope);
            CreateDirectory(path, t);
        }
        public static void CreateDirectory(string path, Transaction transaction)
        {
            int err = apiwindows.CreateDirectoryTransactedW(null, path, new apiwindows.LPSECURITY_ATTRIBUTES(), transaction.TransactionHandle);

            if (err == 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
        }


        public static void Delete(string path, System.Transactions.TransactionScope transactionScope)
        {
            Transaction t = new Transaction(transactionScope);
            Delete(path, t);
        }
        public static void Delete(string path, Transaction transaction)
        {
            int err = apiwindows.RemoveDirectoryTransactedW(path, transaction.TransactionHandle);

            if (err == 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
        }
    }
}
